Swoop logo files
svg: vector, text converted to outlines (scales to any size)
png: transparent background, 4000 px wide
pdf: vector, print ready

Color versions (file name suffix):
color      for white or light backgrounds
reversed   for dark (Night) backgrounds
blue-mono  for Volt Lime backgrounds
white      for Elite Blue backgrounds

01 vertical lockup with tagline, 02 horizontal lockup with tagline, 03 wordmark only,
04 falcon icon, 05 power icon, 06 tagline ideas A to F.
Files with power-o use the power button as the O in SWOOP.
